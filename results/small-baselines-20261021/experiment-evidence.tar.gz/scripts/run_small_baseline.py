"""Wait for a download, check modality wiring, then run a full baseline.

Smoke accuracy is deliberately not a selection criterion. All raw smoke outputs
and failures are retained. Run from the repository root using the GPU Python.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", required=True)
    p.add_argument("--model-id", required=True)
    p.add_argument("--model-path", required=True)
    p.add_argument("--protocol", choices=["all", "VT"], default="all")
    p.add_argument("--download-pid", type=int, required=True)
    p.add_argument("--download-log", required=True)
    args = p.parse_args()
    prefix = f"small-{args.model}"
    out = Path(f"outputs/{prefix}-driver")
    out.mkdir(parents=True, exist_ok=True)
    state = {"args": vars(args), "started_utc": datetime.now(timezone.utc).isoformat(), "commands": []}
    status_path = out / "status.json"

    def save(stage):
        state["stage"] = stage
        state["updated_utc"] = datetime.now(timezone.utc).isoformat()
        status_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        print(stage, flush=True)

    def run(command, log):
        state["commands"].append({"argv": command, "log": log})
        save("running " + log)
        with open(log, "w", encoding="utf-8") as fp:
            subprocess.run(command, stdout=fp, stderr=subprocess.STDOUT, check=True)

    try:
        save("waiting for checkpoint download")
        deadline = time.monotonic() + 3600
        while Path(f"/proc/{args.download_pid}").exists():
            # A completed child can linger as a zombie under container PID 1.
            stat = Path(f"/proc/{args.download_pid}/stat")
            try:
                if stat.read_text().split(") ", 1)[1].startswith("Z"):
                    break
            except FileNotFoundError:
                break
            if time.monotonic() > deadline:
                raise TimeoutError("Download not finished after one hour")
            time.sleep(5)
        last_line = Path(args.download_log).read_text(errors="replace").strip().splitlines()[-1]
        if last_line.strip() != args.model_path:
            raise RuntimeError("Downloader did not report successful checkpoint path")
        base = [sys.executable, "scripts/baseline.py", "--model", args.model,
                "--model-path", args.model_path, "--protocol", args.protocol]
        smoke = f"outputs/{prefix}-smoke"
        run(base + ["--smoke", "--output", smoke], f"logs/{prefix}-smoke.log")
        rows = [json.loads(line) for line in (Path(smoke) / "predictions.jsonl").read_text().splitlines()]
        config = json.loads((Path(smoke) / "config.json").read_text())
        assert len(rows) == config["expected_records"] > 0
        for row in rows:
            assert "error" not in row, row.get("error")
            assert "pixel_values_videos" in row["input_keys"]
            audio = any("audio" in key or key == "input_features" for key in row["input_keys"])
            assert audio == (row["protocol"] == "VA")
            assert row["output_tokens"] > 0
        suffix = "vt" if args.protocol == "VT" else "val"
        run(base + ["--output", f"outputs/{prefix}-{suffix}"], f"logs/{prefix}-{suffix}.log")
        evidence = f"outputs/small-model-evidence/{args.model}"
        run([sys.executable, "scripts/checkpoint_evidence.py", "--model-id", args.model_id,
             "--model-path", args.model_path, "--output", evidence,
             "--hf-metadata-file", f"outputs/hf-metadata-{args.model}.json"],
            f"logs/evidence-{args.model}.log")
        save("complete")
    except Exception as exc:
        state["error"] = repr(exc)
        save("failed")
        raise


if __name__ == "__main__":
    main()
