"""Read a short public weight range to compare download routes."""
import time
import requests

urls = [
    "https://modelscope.cn/models/google/gemma-4-E2B-it/resolve/master/model.safetensors",
    "https://hf-mirror.com/google/gemma-4-E2B-it/resolve/main/model.safetensors",
]
for url in urls:
    started = time.monotonic()
    try:
        with requests.get(url, headers={"Range": "bytes=0-4194303"}, stream=True, timeout=20) as response:
            response.raise_for_status()
            size = 0
            for chunk in response.iter_content(262144):
                size += len(chunk)
                if size >= 4194304:
                    break
            print(url.split("/")[2], response.status_code, size, round(time.monotonic()-started, 2), flush=True)
    except Exception as error:
        print(url.split("/")[2], type(error).__name__, flush=True)
