"""Archive only named experiment artifacts, never datasets, weights or credentials."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def main():
    p = argparse.ArgumentParser()
    p.add_argument("runs", nargs="+")
    p.add_argument("--output", default="results/small-baselines-20261021/experiment-evidence.tar.gz")
    args = p.parse_args()
    files = set()
    for run in args.runs:
        directory = Path(run)
        for name in ["predictions.jsonl", "metrics.json", "config.json", "model_revision.json",
                     "baseline_source.py", "composition_source.py", "status.json"]:
            if (directory / name).exists():
                files.add(directory / name)
    for pattern in [
        "outputs/small-model-evidence/**/*", "logs/small-*.log",
        "logs/download-qwen3b-small.log", "logs/download-qwen35-2b.log",
        "logs/gemma-e2b-val.log", "logs/qwen7b-val.log",
        "logs/evidence-qwen*.log", "logs/evidence-gemma*.log", "scripts/*.py", "docs/小模型*.md",
        "results/small-baselines-20261021/*.json",
        "results/small-baselines-20261021/*.md",
    ]:
        files.update(f for f in Path(".").glob(pattern) if f.is_file())
    for name in ["outputs/small-baseline-audit.json", "requirements-baseline.txt", "docs/基线测试说明.md"]:
        files.add(Path(name))
    target = Path(args.output)
    manifest_path = target.parent / "evidence-files.json"
    files.discard(manifest_path)
    manifest = {
        f.as_posix(): {"bytes": f.stat().st_size, "sha256": hashlib.sha256(f.read_bytes()).hexdigest()}
        for f in sorted(files)
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    with tarfile.open(target, "w:gz") as archive:
        for file in sorted(files | {manifest_path}):
            archive.add(file, arcname=file.as_posix(), recursive=False)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix(target.suffix + ".sha256").write_text(f"{digest}  {target.name}\n", encoding="ascii")
    print(json.dumps({"archive": str(target), "sha256": digest, "files": len(files) + 1,
                      "bytes": target.stat().st_size}))


if __name__ == "__main__":
    main()
