"""Download official, unquantized checkpoints; no remote model code is executed."""
import argparse
from huggingface_hub import snapshot_download

parser = argparse.ArgumentParser()
parser.add_argument("model")
parser.add_argument("--provider", choices=["huggingface", "modelscope"], default="huggingface")
args = parser.parse_args()
if args.provider == "modelscope":
    from modelscope import snapshot_download as ms_download
    path = ms_download(args.model, cache_dir="/workspace/models", max_workers=4)
else:
    path = snapshot_download(
        args.model,
        allow_patterns=["*.json", "*.safetensors", "*.model", "*.jinja", "*.txt"],
        max_workers=4,
    )
print(path, flush=True)
