"""Compact read-only progress snapshot, including failures."""
import json
from pathlib import Path
import sys

for run in sys.argv[1:]:
    path = Path(run)
    rows = []
    pred = path / "predictions.jsonl"
    config = json.loads((path / "config.json").read_text(encoding="utf-8")) if (path / "config.json").exists() else {}
    if pred.exists():
        for line in pred.read_text(encoding="utf-8").splitlines():
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass  # A writer can be in the middle of its last line.
    print(json.dumps({
        "run": run, "completed": len(rows), "expected": config.get("expected_records", 666),
        "errors": sum("error" in r for r in rows),
        "last_seconds": rows[-1]["seconds"] if rows else None,
        "peak_allocated_gib": round(max((r.get("peak_allocated_gib", 0) for r in rows), default=0), 2),
    }), flush=True)
