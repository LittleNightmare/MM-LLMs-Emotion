"""Report complete, protocol-matched baseline runs without repairing predictions."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re

EMOTION_FIELD = re.compile(r'"pred_emotion"\s*:\s*"(negative|positive|neutral)"')


def pct(x):
    return f"{x * 100:.2f}%"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("runs", nargs="+")
    parser.add_argument("--output", default="docs/小模型基线结果.md")
    parser.add_argument("--snapshot", default="results/small-baselines-20261021")
    args = parser.parse_args()
    gold = [json.loads(s) for s in Path("Dataset/val.jsonl").read_text(encoding="utf-8").splitlines()]
    snapshot = Path(args.snapshot)
    snapshot.mkdir(parents=True, exist_ok=True)
    runs = []
    diagnostics = {}
    for name in args.runs:
        path = Path(name)
        cfg = json.loads((path / "config.json").read_text(encoding="utf-8"))
        rows = [json.loads(s) for s in (path / "predictions.jsonl").read_text(encoding="utf-8").splitlines()]
        scope = cfg.get("protocol", "all")
        expected = {r["sample_id"] for r in gold if scope == "all" or r["protocol"] == scope}
        assert len(rows) == len(expected) and {r["sample_id"] for r in rows} == expected, name
        m = json.loads((path / "metrics.json").read_text(encoding="utf-8"))
        for group in ["all", "VT", "VA"]:
            subset = rows if group == "all" else [r for r in rows if r["protocol"] == group]
            assert m[group]["n"] == len(subset)
            if subset:
                acc = sum(r.get("prediction", {}).get("pred_emotion") == r["gold_emotion"] for r in subset) / len(subset)
                assert abs(acc - m[group]["emotion_accuracy"]) < 1e-12
        rev = json.loads((path / "model_revision.json").read_text(encoding="utf-8"))
        runs.append((path, rows, cfg, m, rev))
        for file in ["metrics.json", "config.json", "model_revision.json"]:
            (snapshot / f"{path.name}-{file}").write_bytes((path / file).read_bytes())
        diagnostics[path.name] = {}
        for group in ["all", "VT", "VA"]:
            subset = rows if group == "all" else [r for r in rows if r["protocol"] == group]
            counts = Counter()
            for r in subset:
                label = r.get("prediction", {}).get("pred_emotion")
                label = label if label in ("positive", "negative", "neutral") else "__invalid__"
                counts[f"{r['gold_emotion']} -> {label}"] += 1
            diagnostics[path.name][group] = dict(sorted(counts.items()))
    lines = [
        "# 小模型基线结果", "", "2026-10-21。", "",
        "## 1. 测了哪些模型", "",
        "本轮新增 Qwen3.5-0.8B、Qwen3.5-2B 和 Qwen2.5-Omni-3B。"
        "前两个只测 VT（视频＋文字）；Omni-3B 测完整验证集。"
        "之前测过的 Gemma 4 E2B 和 Omni-7B 保留为对照，7B 不再作为默认训练方案。"
        "候选来源和取舍见 [小模型候选](小模型候选.md)。",
        "", "## 2. 完整任务结果", "",
        "仅比较能同时完成 VT 和 VA 的模型，共 666 条：VT 345 条，VA 321 条。",
        "", "| 模型 | 全部准确率 | VT 准确率 | VA 准确率 | Macro-F1（出现类别） | 冲突 F1 | JSON 合格率 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m, rev in runs:
        if cfg.get("protocol", "all") != "all":
            continue
        a = m["all"]
        lines.append(f"| {cfg['model_id']} | {pct(a['emotion_accuracy'])} | {pct(m['VT']['emotion_accuracy'])} | "
                     f"{pct(m['VA']['emotion_accuracy'])} | {a['emotion_macro_f1_present']:.4f} | "
                     f"{a['conflict_f1']:.4f} | {pct(a['json_valid_rate'])} |")
    lines += [
        "", "## 3. 相同的 VT 子集", "",
        "下面全部使用同一组 345 条视频＋文字样本。Qwen3.5 的结果不能代表 VA。",
        "", "| 模型 | 准确率 | Macro-F1（出现类别） | 冲突 F1 | 冲突召回率 | JSON 合格率 |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m, rev in runs:
        a = m["VT"]
        lines.append(f"| {cfg['model_id']} | {pct(a['emotion_accuracy'])} | {a['emotion_macro_f1_present']:.4f} | "
                     f"{a['conflict_f1']:.4f} | {pct(a['conflict_recall'])} | {pct(a['json_valid_rate'])} |")
    lines += [
        "", "## 4. 资源和输出", "",
        "| 模型 | 实际加载参数 | 测试条数 | 显存峰值 | 运行错误 | 输出达到 192 token 上限 | 无法解析情感的条数 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m, rev in runs:
        params = f"{rev['loaded_parameters'] / 1e9:.3f}B" if "loaded_parameters" in rev else "上轮未记录"
        capped = sum(r.get("output_tokens", 0) >= cfg["max_new_tokens"] for r in rows)
        invalid = sum(r.get("prediction", {}).get("pred_emotion") not in ("negative", "positive", "neutral") for r in rows)
        lines.append(f"| {cfg['model_id']} | {params} | {len(rows)} | {m['max_peak_allocated_gib']:.2f} GiB | "
                     f"{m['all']['error_count']} | {capped} | {invalid} |")
    lines += [
        "", "显存是 PyTorch 已分配显存的峰值；缓存预留和 CUDA 开销会使 nvidia-smi 的读数更高，"
        "不能直接把表中数值当作显卡容量下限。训练时还需要梯度、优化器和激活空间。"
        "Omni 只加载文本回答所需的 Thinker，不加载语音输出部分。"
        "模型名称中的参数数目不一定等于完整加载参数。实际训练占用还需单独测量。",
        "", "所有模型沿用同一提示词、8 帧、最长边 448 像素、BF16、贪心生成和 192 token 上限。"
        "Qwen3.5 关闭 thinking。相同媒体经各自处理器编码，token 数可能不同。"
        "运行存在并发和缓存差异，耗时只作为记录，不作严格速度排名。",
        "", "无法解析的回答计入准确率分母；JSON 合格率另行计算，没有自动修复输出。"
        "验证集没有 neutral 真值，表中 Macro-F1 采用实际出现的两类；固定三类指标保存在 metrics.json。"
        "这些是本地验证指标，不是 Kaggle 分数。",
    ]
    for group in ["all", "VT", "VA"]:
        subset = gold if group == "all" else [r for r in gold if r["protocol"] == group]
        labels = Counter(r["views"]["M12"]["label"] for r in subset)
        lines.append(f"\n{group} 类别分布：{dict(labels)}；全部预测 negative 的准确率为 "
                     f"{pct(labels['negative'] / len(subset))}。")
    lines += [
        "", "## 5. 格式问题的诊断", "",
        "以下只在相同 VT 子集上，从原文匹配恰好一个合法的 `pred_emotion` 字段；"
        "没有匹配或匹配多个字段均记错。它忽略 JSON 其余部分是否合格，只用于分析格式带来的损失，"
        "不是主指标，也没有修改原始预测文件。",
        "", "| 模型 | 主指标准确率 | 只读取情感字段的诊断准确率 | 原文中可读取的情感字段数 |",
        "| --- | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m, rev in runs:
        subset = [r for r in rows if r["protocol"] == "VT"]
        parsed = [(r, EMOTION_FIELD.findall(r.get("raw_output", ""))) for r in subset]
        valid = [(r, labels[0]) for r, labels in parsed if len(labels) == 1]
        correct = sum(label == r["gold_emotion"] for r, label in valid)
        lines.append(f"| {cfg['model_id']} | {pct(m['VT']['emotion_accuracy'])} | "
                     f"{pct(correct / len(subset))} | {len(valid)} / {len(subset)} |")
        diagnostics[path.name]["VT_raw_emotion_field_diagnostic"] = {
            "n": len(subset), "valid_fields": len(valid), "correct": correct,
            "accuracy": correct / len(subset), "parser": EMOTION_FIELD.pattern,
        }
    for path, rows, cfg, m, rev in runs:
        unquoted = sum(bool(re.search(r'"clarifying_question"\s*:\s*none\b', r.get("raw_output", ""))) for r in rows)
        boolean = sum(bool(re.search(r'"is_conflict"\s*:\s*(true|false)\b', r.get("raw_output", ""))) for r in rows)
        diagnostics[path.name]["format_diagnostics"] = {
            "unquoted_none": unquoted, "boolean_instead_of_yes_no": boolean,
        }
        if unquoted or boolean:
            lines.append(f"\n{cfg['model_id']} 的 {len(rows)} 条回答中，{unquoted} 条把 `none` 写成未加引号的值，"
                         f"{boolean} 条把冲突字段写成布尔值。两种情况可能出现在同一条回答中。")
    lines += ["", "## 6. 冲突与追问", "",
              "| 模型 | 冲突样本检出数 / 总数 | 回答不确定 | 非空追问 |",
              "| --- | ---: | ---: | ---: |"]
    for path, rows, cfg, m, rev in runs:
        conflicts = [r for r in rows if r["gold_conflict"] == "yes"]
        tp = sum(r.get("prediction", {}).get("is_conflict") == "yes" for r in conflicts)
        uncertain = sum(r.get("prediction", {}).get("is_uncertain") == "yes" for r in rows)
        questions = sum(r.get("prediction", {}).get("clarifying_question") not in (None, "", "none") for r in rows)
        lines.append(f"| {cfg['model_id']} | {tp} / {len(conflicts)} | {uncertain} | {questions} |")
    lines += ["", "不确定性与追问没有标准答案，上表只是行为统计。VT 模型与全任务模型的样本范围不同，"
              "不能直接按此表的检出数量排名。", "", "## 7. 实验文件", ""]
    for path, rows, cfg, m, rev in runs:
        lines.append(f"- `{path.as_posix()}/`：原始回答、指标、配置、实际执行的脚本副本。")
    lines += [
        "- `outputs/small-model-evidence/`：模型卡、配置、权重 SHA256 与官方仓库版本校验。",
        "- `outputs/small-baseline-audit.json`：覆盖数量、ID、标签、模态输入和媒体哈希检查。",
        f"- `{snapshot.as_posix()}/`：便于版本管理的配置、指标和分类混淆统计。",
        "- `results/small-baselines-20261021/experiment-evidence.tar.gz`：原始回答、脚本、日志和模型来源的压缩备份；不包含模型权重和课程视频。",
        "", "## 8. 权重来源校验", "",
        "| 模型 | 全部权重 SHA256 与官方仓库相同 | 对应官方提交（缩写） |",
        "| --- | --- | --- |",
    ]
    for path, rows, cfg, m, rev in runs:
        evidence = Path("outputs/small-model-evidence") / cfg["model"] / "checkpoint_manifest.json"
        info = json.loads(evidence.read_text(encoding="utf-8"))
        matched = "是" if info.get("all_weight_hashes_match_official") else "未确认"
        commit = info.get("weight_verified_commit")
        lines.append(f"| {cfg['model_id']} | {matched} | {commit[:12] if commit else '未确认'} |")
    lines += [
        "", "完整 SHA256 和提交号保存在证据包中。旧的 Gemma E2B 和 Omni-7B 在本轮补录了"
        "其原路径下权重的哈希；它们的推理结果仍来自上一轮，未重新推理。",
    ]
    route = Path("outputs/small-protocol-routing")
    if route.exists():
        route_metrics = json.loads((route / "metrics.json").read_text(encoding="utf-8"))
        a = route_metrics["all"]
        lines += [
            "", "## 9. 按协议分流的组合", "",
            "还做了一项离线组合：VT 固定使用 Qwen3.5-2B，VA 固定使用 Qwen2.5-Omni-3B。"
            "只按输入协议选择模型，不按正确答案或单条预测是否正确挑结果。",
            "", f"组合后 666 条的情感准确率为 **{pct(a['emotion_accuracy'])}**，"
            f"Macro-F1（出现类别）为 **{a['emotion_macro_f1_present']:.4f}**，"
            f"JSON 合格率为 **{pct(a['json_valid_rate'])}**，冲突 F1 为 **{a['conflict_f1']:.4f}**。",
            "", "这是两个模型的组合方案，不是新的单模型成绩。它是在查看验证结果后提出的候选，"
            "还需要独立测试集验证。这里只复用了已保存的预测，未实测组合部署的延迟和显存。"
            "若后续采用此方案，原始、SFT、RL 三个阶段都应保持同样的分流规则。",
            "", "组合预测、来源文件哈希和脚本保存在 `outputs/small-protocol-routing/`，也收入证据包。",
        ]
        for file in ["metrics.json", "config.json"]:
            (snapshot / f"small-protocol-routing-{file}").write_bytes((route / file).read_bytes())
    lines += ["", "本轮未进行 SFT 或 RL，未向 Kaggle 提交。", ""]
    (snapshot / "confusion_counts.json").write_text(json.dumps(diagnostics, ensure_ascii=False, indent=2), encoding="utf-8")
    Path(args.output).write_text("\n".join(lines), encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
