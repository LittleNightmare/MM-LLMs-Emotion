"""Generate a report only after every model has covered the full validation set."""
import argparse
from collections import Counter
import json
from pathlib import Path


def percent(value):
    return f"{100 * value:.2f}%"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("runs", nargs="+")
    parser.add_argument("--dataset", default="Dataset/val.jsonl")
    parser.add_argument("--output", default="docs/基线测试结果.md")
    args = parser.parse_args()
    gold = [json.loads(s) for s in Path(args.dataset).read_text(encoding="utf-8").splitlines()]
    expected = {r["sample_id"] for r in gold}
    runs = []
    for name in args.runs:
        path = Path(name)
        rows = [json.loads(s) for s in (path / "predictions.jsonl").read_text(encoding="utf-8").splitlines()]
        ids = [r["sample_id"] for r in rows]
        if len(ids) != len(set(ids)) or set(ids) != expected:
            raise ValueError(f"{path}: incomplete/duplicate validation predictions ({len(ids)}/{len(expected)})")
        config = json.loads((path / "config.json").read_text(encoding="utf-8"))
        metrics = json.loads((path / "metrics.json").read_text(encoding="utf-8"))
        assert metrics["all"]["n"] == len(rows)
        runs.append((path, rows, config, metrics))
    lines = [
        "# 原始模型基线结果", "", "2026-10-21。", "",
        "## 1. 测试设置", "",
        f"完整验证集 {len(gold)} 条。服务器显卡为 RTX 4090 48GB。"
        "所有模型使用未经过本任务训练的指令权重、BF16、贪心解码、相同提示词和媒体缓存。"
        "每段视频均匀取 8 帧，最长边 448 像素；VA 同时输入完整的 16kHz 单声道音频，VT 不输入音频。",
        "", "## 2. 全量结果", "",
        "| 模型 | 情感准确率 | Macro-F1（出现类别） | Macro-F1（固定三类） | 冲突 F1 | 冲突召回率 | JSON 合格率 | 运行错误 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m in runs:
        a = m["all"]
        lines.append(f"| {cfg['model_id']} | {percent(a['emotion_accuracy'])} | "
                     f"{a['emotion_macro_f1_present']:.4f} | {a['emotion_macro_f1_fixed3']:.4f} | "
                     f"{a['conflict_f1']:.4f} | {percent(a['conflict_recall'])} | "
                     f"{percent(a['json_valid_rate'])} | {a['error_count']} |")
    counts = Counter(r["views"]["M12"]["label"] for r in gold)
    no_conflict = sum(r["sample_type"] == "Aligned" for r in gold) / len(gold)
    majority = max(counts, key=counts.get)
    lines += [
        "", f"验证集类别数量：{dict(counts)}。没有 neutral 样本，因此固定三类的 Macro-F1 "
        "会把 neutral 的 F1 按 0 计。两种口径都保留，正式竞赛分数需按竞赛规则计算。",
        "", f"全部预测 {majority} 的情感准确率为 {percent(counts[majority]/len(gold))}；"
        f"全部预测无冲突的冲突准确率为 {percent(no_conflict)}。冲突识别需要结合 F1、召回率判断。",
        "", "## 3. 分组结果", "",
        "| 模型 | 分组 | 数量 | 情感准确率 | Macro-F1（出现类别） | 冲突 F1 |",
        "| --- | --- | ---: | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m in runs:
        for group in ["VT", "VA", "real", "generated", "use_in_main"]:
            a = m[group]
            lines.append(f"| {cfg['model_id']} | {group} | {a['n']} | {percent(a['emotion_accuracy'])} | "
                         f"{a['emotion_macro_f1_present']:.4f} | {a['conflict_f1']:.4f} |")
    lines += [
        "", "## 4. 不确定性和输出情况", "",
        "| 模型 | 回答不确定的比例 | 提出非空追问的数量 | 达到输出上限的数量 | 峰值已分配显存 | 单条耗时中位数 |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for path, rows, cfg, m in runs:
        questions = sum(r.get("prediction", {}).get("clarifying_question") not in (None, "", "none") for r in rows)
        capped = sum(r.get("output_tokens", 0) >= cfg["max_new_tokens"] for r in rows)
        lines.append(f"| {cfg['model_id']} | {percent(m['all']['uncertain_rate'])} | {questions} | {capped} | "
                     f"{m['max_peak_allocated_gib']:.2f} GiB | {m['median_seconds']:.2f} 秒 |")
    lines += [
        "", "这里的显存是 PyTorch 已分配显存峰值，不包括所有 CUDA 和驱动开销。"
        "单条耗时包含预处理和推理；复用缓存、首次编译和并发运行都会影响耗时，不作为严格的模型速度排名。",
        "", "数据没有独立的不确定性标准答案。回答不确定的比例和追问数量都是行为统计，"
        "不能当作准确率或过度判断率。模型在缺少中性样本的验证集上预测 neutral 会被记错，"
        "需结合样本人工分析，不能直接据此认定模型完全没有情感理解能力。",
        "", "## 5. 预测文件", "",
    ]
    for path, rows, cfg, m in runs:
        lines.append(f"- `{path.as_posix()}/predictions.jsonl`：{cfg['model_id']} 的逐条回答。")
        lines.append(f"- `{path.as_posix()}/config.json`、`metrics.json`：运行配置与完整指标。")
    lines += [
        "", "本次没有训练模型，也没有生成或提交 Kaggle 测试集答案。"
        "后续在固定输入和输出规则下进行 SFT，再比较 SFT 与 SFT＋RL。", "",
    ]
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
